
# LoRa Database Sync - Tkinter

Aplikasi Python + Tkinter untuk mengambil data dari MySQL/MariaDB di:

    192.168.137.241

lalu menyinkronkannya ke database MySQL/MariaDB di laptop tujuan.

## Konsep

Laptop boleh mati.

Data baru tetap masuk ke database source di 192.168.137.241.

Saat laptop dinyalakan dan aplikasi dijalankan:

    Source 192.168.137.241
            |
            v
      Python Sync
            |
            v
      Laptop terpilih

Program menyimpan watermark terakhir yang berhasil disinkronkan di:

    lora_sync_state.json

Contoh:

    last watermark = 2026-09-29 18:30:00
    last pk        = 123456

Jadi ketika besok aplikasi dijalankan, program mengambil data setelah posisi tersebut.

## 1. Install Python

Windows:

    python --version

Tkinter biasanya sudah ikut jika memakai installer Python resmi.

## 2. Install library

    python -m pip install mysql-connector-python

## 3. Jalankan

    python lora_db_sync.py

Pertama kali aplikasi membuat:

    lora_sync_config.json
    lora_sync_state.json

## 4. Isi Source

Tab "Source":

    Host     : 192.168.137.241
    Port     : 3306
    Username : user MySQL source
    Password : password MySQL source
    Database : database source

## 5. Tambahkan laptop tujuan

Tab "Laptop".

Contoh laptop lokal:

    Nama Laptop : Laptop Produksi
    IP / Host   : 127.0.0.1
    Port        : 3306
    Username    : sync_user
    Password    : password
    Database    : database_tps_core

Laptop lain bisa ditambahkan:

    Laptop 2    -> 192.168.137.50
    Laptop 3    -> 192.168.137.51

Kemudian pada tab Sync tinggal pilih laptop tujuan.

## 6. Atur tabel

Tab "Tabel".

Format:

    source_table | destination_table | watermark_column | primary_key

Contoh:

    tb_kub1_total_kwh | tb_kub1_total_kwh | date_time | id
    produksi          | produksi          | id        | id

Untuk tabel dengan kolom waktu:

    nama_tabel | nama_tabel | date_time | id

Untuk tabel dengan UUID atau PK lain:

    nama_tabel | nama_tabel | updated_at | id_uuid

Watermark harus merupakan kolom yang dapat dipakai untuk mengetahui data baru/perubahan.

Primary key sangat disarankan diisi.

## 7. Test

Pada tab Sync:

    pilih laptop
    klik Test Connection
    klik SYNC SEKARANG

## 8. Auto Sync

Centang:

    Aktifkan auto sync selama aplikasi berjalan

Misalnya:

    Interval = 300

Maka aplikasi akan mencoba sync setiap 5 menit selama program tetap terbuka.

## Catatan penting

1. Source MySQL di 192.168.137.241 harus menerima koneksi dari laptop.
2. Destination MySQL harus menerima koneksi dari aplikasi.
3. Struktur tabel source dan destination harus kompatibel.
4. Destination sebaiknya memiliki PRIMARY KEY/UNIQUE KEY yang sama agar UPSERT bekerja.
5. Untuk tabel yang memakai timestamp, gunakan primary key sebagai pasangan watermark untuk mencegah row dengan timestamp sama terlewat.
6. Password saat ini disimpan di file config.json. Untuk jaringan produksi, sebaiknya nanti kita pindahkan credential ke Windows Credential Manager atau .env yang tidak ikut dibagikan.
7. Program ini tidak menghapus data destination. Ia hanya insert/update berdasarkan key destination.

## Rekomendasi arsitektur untuk kondisi shift

    LoRa
      |
      v
    192.168.137.241
      |
      +--> Database source (selalu aktif)
      |
      +--> laptop saat shift 1 ON --> sync
      |
      +--> laptop OFF              --> data tetap tertahan di source
                                        |
                                        v
                              laptop hidup kembali
                                        |
                                        v
                                  catch-up sync

Jadi tidak perlu menjaga laptop tetap ON hanya agar data tidak hilang.
