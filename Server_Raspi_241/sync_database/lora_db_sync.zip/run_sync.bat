@echo off
cd /d "%~dp0"
python lora_sync.py
pause
