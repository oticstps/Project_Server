
import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path
import json
import threading
import queue
import traceback

APP_DIR = Path(__file__).resolve().parent
CONFIG_FILE = APP_DIR / "lora_sync_config.json"
STATE_FILE = APP_DIR / "lora_sync_state.json"

DEFAULT_CONFIG = {
    "source": {
        "host": "192.168.137.241",
        "port": 3306,
        "user": "sync_user",
        "password": "CHANGE_ME",
        "database": "database_tps_core",
        "charset": "utf8mb4"
    },
    "destinations": {
        "Laptop Utama": {
            "host": "127.0.0.1",
            "port": 3306,
            "user": "sync_user",
            "password": "CHANGE_ME",
            "database": "database_tps_core",
            "charset": "utf8mb4"
        }
    },

    # Tambahkan tabel yang memang ingin disinkronkan.
    #
    # watermark_column:
    #   Kolom yang bertambah/berubah ketika ada data baru.
    #   Contoh umum: id, idPrimary, id_uuid, date_time, created_at, updated_at
    #
    # primary_key:
    #   PK tabel. Sangat disarankan diisi agar data dengan timestamp yang sama
    #   tidak terlewat.
    "sync_tables": [
        # Contoh:
        # {
        #     "source_table": "tb_kub1_total_kwh",
        #     "destination_table": "tb_kub1_total_kwh",
        #     "watermark_column": "date_time",
        #     "primary_key": "id"
        # }
    ],

    "batch_size": 500,
    "auto_sync_enabled": False,
    "auto_sync_seconds": 300
}


def json_default(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat(sep=" ")
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, bytes):
        return obj.decode(errors="replace")
    return str(obj)


def load_json(path, default):
    try:
        if not path.exists():
            path.write_text(
                json.dumps(default, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
            return json.loads(json.dumps(default))
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return json.loads(json.dumps(default))


def save_json(path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(data, indent=2, ensure_ascii=False, default=json_default),
        encoding="utf-8"
    )
    tmp.replace(path)


class MySQLSync:
    def __init__(self, config, state, log_callback=None):
        self.config = config
        self.state = state
        self.log_callback = log_callback or (lambda _: None)
        self.stop_event = threading.Event()

    def log(self, text):
        self.log_callback(text)

    def stop(self):
        self.stop_event.set()

    def connect(self, settings):
        return mysql.connector.connect(
            host=settings["host"],
            port=int(settings.get("port", 3306)),
            user=settings["user"],
            password=settings["password"],
            database=settings["database"],
            charset=settings.get("charset", "utf8mb4"),
            connection_timeout=5,
            autocommit=False,
        )

    def test_connection(self, settings):
        conn = self.connect(settings)
        cur = conn.cursor()
        try:
            cur.execute("SELECT VERSION()")
            return cur.fetchone()[0]
        finally:
            cur.close()
            conn.close()

    @staticmethod
    def quote(name):
        if not isinstance(name, str):
            raise ValueError("Nama tabel/kolom harus string.")
        # Hanya izinkan identifier sederhana: huruf, angka, _, $
        if not name.replace("_", "").replace("$", "").isalnum():
            raise ValueError(f"Nama tabel/kolom tidak valid: {name}")
        return f"`{name}`"

    def table_columns(self, conn, table):
        cur = conn.cursor()
        try:
            cur.execute(f"SHOW COLUMNS FROM {self.quote(table)}")
            return [row[0] for row in cur.fetchall()]
        finally:
            cur.close()

    def sync_one_table(self, src_conn, dst_conn, destination_name, table_cfg):
        src_table = table_cfg["source_table"]
        dst_table = table_cfg.get("destination_table") or src_table
        wm_col = table_cfg["watermark_column"]
        pk_col = table_cfg.get("primary_key")

        src_cols = self.table_columns(src_conn, src_table)
        dst_cols = self.table_columns(dst_conn, dst_table)

        common_cols = [c for c in src_cols if c in dst_cols]
        if not common_cols:
            raise RuntimeError(
                f"Tidak ada kolom yang sama antara {src_table} dan {dst_table}"
            )

        if wm_col not in common_cols:
            raise RuntimeError(
                f"Watermark '{wm_col}' tidak ada pada source dan destination."
            )

        if pk_col and pk_col not in common_cols:
            raise RuntimeError(
                f"Primary key '{pk_col}' tidak ada pada source dan destination."
            )

        state_key = f"{destination_name}::{src_table}"
        table_state = self.state.get(state_key, {})
        last_wm = table_state.get("last_watermark")
        last_pk = table_state.get("last_pk")

        col_sql = ", ".join(self.quote(c) for c in common_cols)
        select_cur = src_conn.cursor(dictionary=True)
        insert_cur = dst_conn.cursor()

        batch_size = max(1, int(self.config.get("batch_size", 500)))
        total = 0

        try:
            while not self.stop_event.is_set():
                params = []

                if last_wm is None:
                    where_sql = ""
                elif pk_col and last_pk is not None:
                    where_sql = (
                        f"WHERE ({self.quote(wm_col)} > %s "
                        f"OR ({self.quote(wm_col)} = %s "
                        f"AND {self.quote(pk_col)} > %s))"
                    )
                    params.extend([last_wm, last_wm, last_pk])
                else:
                    where_sql = f"WHERE {self.quote(wm_col)} > %s"
                    params.append(last_wm)

                order_sql = f"ORDER BY {self.quote(wm_col)} ASC"
                if pk_col:
                    order_sql += f", {self.quote(pk_col)} ASC"

                select_sql = (
                    f"SELECT {col_sql} "
                    f"FROM {self.quote(src_table)} "
                    f"{where_sql} "
                    f"{order_sql} "
                    f"LIMIT %s"
                )
                params.append(batch_size)

                select_cur.execute(select_sql, params)
                rows = select_cur.fetchall()

                if not rows:
                    break

                placeholders = ", ".join(["%s"] * len(common_cols))
                insert_cols = ", ".join(self.quote(c) for c in common_cols)

                # Upsert berdasarkan UNIQUE/PRIMARY KEY di destination.
                update_cols = [
                    c for c in common_cols
                    if not pk_col or c != pk_col
                ]

                if update_cols:
                    update_sql = ", ".join(
                        f"{self.quote(c)} = VALUES({self.quote(c)})"
                        for c in update_cols
                    )
                    insert_sql = (
                        f"INSERT INTO {self.quote(dst_table)} "
                        f"({insert_cols}) "
                        f"VALUES ({placeholders}) "
                        f"ON DUPLICATE KEY UPDATE {update_sql}"
                    )
                else:
                    insert_sql = (
                        f"INSERT IGNORE INTO {self.quote(dst_table)} "
                        f"({insert_cols}) VALUES ({placeholders})"
                    )

                values = [
                    [row[c] for c in common_cols]
                    for row in rows
                ]

                insert_cur.executemany(insert_sql, values)
                dst_conn.commit()

                last_row = rows[-1]
                last_wm = last_row[wm_col]
                if pk_col:
                    last_pk = last_row[pk_col]

                self.state[state_key] = {
                    "last_watermark": json_default(last_wm),
                    "last_pk": json_default(last_pk) if pk_col else None,
                    "updated_at": datetime.now().isoformat(timespec="seconds")
                }
                save_json(STATE_FILE, self.state)

                total += len(rows)
                self.log(
                    f"  {src_table}: +{len(rows):,} row "
                    f"(total sesi {total:,})"
                )

            if self.stop_event.is_set():
                self.log(f"  {src_table}: dihentikan oleh user.")
            elif total == 0:
                self.log(f"  {src_table}: tidak ada data baru.")

            return total

        except Exception:
            dst_conn.rollback()
            raise
        finally:
            select_cur.close()
            insert_cur.close()

    def sync_destination(self, destination_name):
        destinations = self.config.get("destinations", {})
        if destination_name not in destinations:
            raise RuntimeError(f"Destination '{destination_name}' tidak ditemukan.")

        table_configs = self.config.get("sync_tables", [])
        if not table_configs:
            raise RuntimeError(
                "Belum ada tabel sync. Buka tab 'Tabel' dan tambahkan konfigurasi."
            )

        src = self.config["source"]
        dst = destinations[destination_name]

        self.log("=" * 72)
        self.log(f"SYNC -> {destination_name}")
        self.log(
            f"Source      : {src['host']}:{src.get('port', 3306)}/{src['database']}"
        )
        self.log(
            f"Destination : {dst['host']}:{dst.get('port', 3306)}/{dst['database']}"
        )

        src_conn = None
        dst_conn = None

        try:
            src_conn = self.connect(src)
            dst_conn = self.connect(dst)
            self.log("Koneksi source dan destination: OK")

            grand_total = 0
            for table_cfg in table_configs:
                if self.stop_event.is_set():
                    break
                grand_total += self.sync_one_table(
                    src_conn,
                    dst_conn,
                    destination_name,
                    table_cfg
                )

            if self.stop_event.is_set():
                self.log(
                    f"SYNC DIHENTIKAN -> {destination_name} | "
                    f"total tersalin sesi ini {grand_total:,} row"
                )
            else:
                self.log(
                    f"SYNC SELESAI -> {destination_name} | "
                    f"total {grand_total:,} row"
                )

            return grand_total

        finally:
            if src_conn:
                src_conn.close()
            if dst_conn:
                dst_conn.close()


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("LoRa Database Sync")
        self.geometry("1000x680")
        self.minsize(860, 560)

        self.config_data = load_json(CONFIG_FILE, DEFAULT_CONFIG)
        self.state = load_json(STATE_FILE, {})

        self.log_queue = queue.Queue()
        self.sync_thread = None
        self.current_syncer = None
        self.auto_after_id = None

        self.build_ui()
        self.load_all_forms()
        self.refresh_destination_combo()

        self.after(100, self.process_log_queue)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        if self.config_data.get("auto_sync_enabled"):
            self.auto_var.set(True)
            self.schedule_auto_sync(initial=True)

    def build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab_sync = ttk.Frame(notebook, padding=12)
        self.tab_dest = ttk.Frame(notebook, padding=12)
        self.tab_source = ttk.Frame(notebook, padding=12)
        self.tab_tables = ttk.Frame(notebook, padding=12)

        notebook.add(self.tab_sync, text="Sync")
        notebook.add(self.tab_dest, text="Laptop")
        notebook.add(self.tab_source, text="Source")
        notebook.add(self.tab_tables, text="Tabel")

        self.build_sync_tab()
        self.build_dest_tab()
        self.build_source_tab()
        self.build_tables_tab()

    def build_sync_tab(self):
        target = ttk.LabelFrame(self.tab_sync, text="Target Sync", padding=12)
        target.pack(fill="x")

        ttk.Label(target, text="Laptop tujuan:").grid(
            row=0, column=0, sticky="w"
        )

        self.dest_var = tk.StringVar()
        self.dest_combo = ttk.Combobox(
            target,
            textvariable=self.dest_var,
            state="readonly",
            width=32
        )
        self.dest_combo.grid(row=0, column=1, padx=8, sticky="w")

        self.test_btn = ttk.Button(
            target, text="Test Connection", command=self.test_destination
        )
        self.test_btn.grid(row=0, column=2, padx=5)

        self.sync_btn = ttk.Button(
            target, text="SYNC SEKARANG", command=self.start_sync
        )
        self.sync_btn.grid(row=0, column=3, padx=5)

        self.stop_btn = ttk.Button(
            target,
            text="STOP",
            command=self.stop_sync,
            state="disabled"
        )
        self.stop_btn.grid(row=0, column=4, padx=5)

        auto = ttk.LabelFrame(self.tab_sync, text="Auto Sync", padding=12)
        auto.pack(fill="x", pady=(12, 0))

        self.auto_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            auto,
            text="Aktifkan auto sync selama aplikasi berjalan",
            variable=self.auto_var,
            command=self.toggle_auto_sync,
        ).grid(row=0, column=0, sticky="w")

        ttk.Label(auto, text="Interval detik:").grid(
            row=1, column=0, sticky="w", pady=(8, 0)
        )

        self.interval_var = tk.StringVar(value="300")
        ttk.Entry(
            auto, textvariable=self.interval_var, width=10
        ).grid(row=1, column=1, sticky="w", pady=(8, 0))

        info = ttk.LabelFrame(self.tab_sync, text="Status", padding=12)
        info.pack(fill="x", pady=(12, 0))

        self.status_var = tk.StringVar(value="Siap.")
        ttk.Label(info, textvariable=self.status_var).pack(anchor="w")

        logs = ttk.LabelFrame(self.tab_sync, text="Log", padding=8)
        logs.pack(fill="both", expand=True, pady=(12, 0))

        self.log_text = tk.Text(logs, wrap="none")
        self.log_text.pack(side="left", fill="both", expand=True)

        scroll = ttk.Scrollbar(logs, command=self.log_text.yview)
        scroll.pack(side="right", fill="y")
        self.log_text.configure(yscrollcommand=scroll.set)

    def build_dest_tab(self):
        form = ttk.Frame(self.tab_dest)
        form.pack(fill="x")

        self.dest_name_var = tk.StringVar()
        self.dest_host_var = tk.StringVar()
        self.dest_port_var = tk.StringVar(value="3306")
        self.dest_user_var = tk.StringVar()
        self.dest_pass_var = tk.StringVar()
        self.dest_db_var = tk.StringVar()

        fields = [
            ("Nama Laptop", self.dest_name_var),
            ("IP / Host", self.dest_host_var),
            ("Port", self.dest_port_var),
            ("Username", self.dest_user_var),
            ("Password", self.dest_pass_var),
            ("Database", self.dest_db_var),
        ]

        for row, (label, variable) in enumerate(fields):
            ttk.Label(form, text=label, width=16).grid(
                row=row, column=0, sticky="w", pady=5
            )
            show = "*" if label == "Password" else None
            ttk.Entry(
                form,
                textvariable=variable,
                width=42,
                show=show
            ).grid(row=row, column=1, sticky="w", pady=5)

        buttons = ttk.Frame(form)
        buttons.grid(row=len(fields), column=0, columnspan=2, sticky="w", pady=12)

        ttk.Button(
            buttons,
            text="Tambah / Update Laptop",
            command=self.save_destination
        ).pack(side="left", padx=(0, 8))

        ttk.Button(
            buttons,
            text="Hapus Laptop",
            command=self.delete_destination
        ).pack(side="left")

        list_frame = ttk.LabelFrame(
            self.tab_dest, text="Laptop tersimpan", padding=8
        )
        list_frame.pack(fill="both", expand=True, pady=(10, 0))

        self.dest_listbox = tk.Listbox(list_frame)
        self.dest_listbox.pack(fill="both", expand=True)
        self.dest_listbox.bind(
            "<<ListboxSelect>>", self.on_destination_selected
        )

    def build_source_tab(self):
        form = ttk.Frame(self.tab_source)
        form.pack(fill="x")

        self.src_host_var = tk.StringVar()
        self.src_port_var = tk.StringVar()
        self.src_user_var = tk.StringVar()
        self.src_pass_var = tk.StringVar()
        self.src_db_var = tk.StringVar()

        fields = [
            ("Host Source", self.src_host_var),
            ("Port", self.src_port_var),
            ("Username", self.src_user_var),
            ("Password", self.src_pass_var),
            ("Database", self.src_db_var),
        ]

        for row, (label, variable) in enumerate(fields):
            ttk.Label(form, text=label, width=16).grid(
                row=row, column=0, sticky="w", pady=5
            )
            show = "*" if label == "Password" else None
            ttk.Entry(
                form,
                textvariable=variable,
                width=42,
                show=show
            ).grid(row=row, column=1, sticky="w", pady=5)

        ttk.Button(
            form,
            text="Simpan Source",
            command=self.save_source
        ).grid(row=len(fields), column=0, columnspan=2, sticky="w", pady=12)

        ttk.Label(
            self.tab_source,
            text="Default source sudah diisi 192.168.137.241."
        ).pack(anchor="w", pady=10)

    def build_tables_tab(self):
        ttk.Label(
            self.tab_tables,
            text=(
                "1 baris = 1 tabel: "
                "source_table | destination_table | watermark_column | primary_key"
            )
        ).pack(anchor="w")

        ttk.Label(
            self.tab_tables,
            text=(
                "Contoh: tb_kub1_total_kwh | tb_kub1_total_kwh | "
                "date_time | id"
            )
        ).pack(anchor="w", pady=(2, 10))

        self.tables_text = tk.Text(
            self.tab_tables, height=16, wrap="none"
        )
        self.tables_text.pack(fill="both", expand=True)

        bottom = ttk.Frame(self.tab_tables)
        bottom.pack(fill="x", pady=10)

        ttk.Label(bottom, text="Batch size:").pack(side="left")

        self.batch_var = tk.StringVar(value="500")
        ttk.Entry(
            bottom, textvariable=self.batch_var, width=10
        ).pack(side="left", padx=8)

        ttk.Button(
            bottom,
            text="Simpan Tabel",
            command=self.save_tables
        ).pack(side="left", padx=8)

    def load_all_forms(self):
        src = self.config_data["source"]

        self.src_host_var.set(src.get("host", ""))
        self.src_port_var.set(str(src.get("port", 3306)))
        self.src_user_var.set(src.get("user", ""))
        self.src_pass_var.set(src.get("password", ""))
        self.src_db_var.set(src.get("database", ""))

        self.interval_var.set(
            str(self.config_data.get("auto_sync_seconds", 300))
        )
        self.batch_var.set(
            str(self.config_data.get("batch_size", 500))
        )

        self.tables_text.delete("1.0", tk.END)

        for table in self.config_data.get("sync_tables", []):
            self.tables_text.insert(
                tk.END,
                f"{table['source_table']} | "
                f"{table.get('destination_table', table['source_table'])} | "
                f"{table['watermark_column']} | "
                f"{table.get('primary_key') or ''}\n"
            )

    def refresh_destination_combo(self):
        names = list(self.config_data.get("destinations", {}).keys())

        self.dest_combo["values"] = names

        self.dest_listbox.delete(0, tk.END)
        for name in names:
            self.dest_listbox.insert(tk.END, name)

        if names:
            current = self.dest_var.get()
            if current not in names:
                current = names[0]
            self.dest_var.set(current)
            self.load_destination_form(current)
        else:
            self.dest_var.set("")

    def load_destination_form(self, name):
        if not name:
            return

        destination = self.config_data["destinations"][name]

        self.dest_name_var.set(name)
        self.dest_host_var.set(destination.get("host", ""))
        self.dest_port_var.set(
            str(destination.get("port", 3306))
        )
        self.dest_user_var.set(destination.get("user", ""))
        self.dest_pass_var.set(destination.get("password", ""))
        self.dest_db_var.set(destination.get("database", ""))

    def on_destination_selected(self, _event=None):
        selection = self.dest_listbox.curselection()
        if not selection:
            return

        name = self.dest_listbox.get(selection[0])
        self.dest_var.set(name)
        self.load_destination_form(name)

    def save_destination(self):
        name = self.dest_name_var.get().strip()

        if not name:
            messagebox.showwarning(
                "Validasi", "Nama laptop wajib diisi."
            )
            return

        try:
            port = int(self.dest_port_var.get())
        except ValueError:
            messagebox.showwarning(
                "Validasi", "Port harus berupa angka."
            )
            return

        self.config_data.setdefault("destinations", {})[name] = {
            "host": self.dest_host_var.get().strip(),
            "port": port,
            "user": self.dest_user_var.get().strip(),
            "password": self.dest_pass_var.get(),
            "database": self.dest_db_var.get().strip(),
            "charset": "utf8mb4",
        }

        save_json(CONFIG_FILE, self.config_data)
        self.refresh_destination_combo()
        self.dest_var.set(name)
        self.log(f"Profile laptop '{name}' disimpan.")

    def delete_destination(self):
        name = self.dest_var.get().strip()

        if not name:
            return

        if len(self.config_data.get("destinations", {})) <= 1:
            messagebox.showwarning(
                "Hapus",
                "Minimal harus ada 1 laptop tujuan."
            )
            return

        if not messagebox.askyesno(
            "Konfirmasi", f"Hapus profile '{name}'?"
        ):
            return

        self.config_data["destinations"].pop(name, None)
        save_json(CONFIG_FILE, self.config_data)
        self.refresh_destination_combo()
        self.log(f"Profile laptop '{name}' dihapus.")

    def save_source(self):
        try:
            port = int(self.src_port_var.get())
        except ValueError:
            messagebox.showwarning(
                "Validasi", "Port source harus berupa angka."
            )
            return

        self.config_data["source"] = {
            "host": self.src_host_var.get().strip(),
            "port": port,
            "user": self.src_user_var.get().strip(),
            "password": self.src_pass_var.get(),
            "database": self.src_db_var.get().strip(),
            "charset": "utf8mb4",
        }

        save_json(CONFIG_FILE, self.config_data)
        self.log("Konfigurasi source disimpan.")

    def save_tables(self):
        lines = [
            line.strip()
            for line in self.tables_text.get("1.0", tk.END).splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]

        tables = []

        try:
            for line in lines:
                parts = [part.strip() for part in line.split("|")]

                if len(parts) != 4:
                    raise ValueError(
                        f"Format salah:\n{line}\n\n"
                        "Format wajib:\n"
                        "source | destination | watermark | primary_key"
                    )

                source, destination, watermark, primary_key = parts

                if not source or not watermark:
                    raise ValueError(
                        f"Source table dan watermark wajib diisi:\n{line}"
                    )

                tables.append({
                    "source_table": source,
                    "destination_table": destination or source,
                    "watermark_column": watermark,
                    "primary_key": primary_key or None,
                })

            self.config_data["sync_tables"] = tables
            self.config_data["batch_size"] = max(
                1, int(self.batch_var.get())
            )

            save_json(CONFIG_FILE, self.config_data)

            self.log(f"{len(tables)} tabel sync disimpan.")
            messagebox.showinfo(
                "Tersimpan",
                "Konfigurasi tabel berhasil disimpan."
            )

        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    def log(self, message):
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.log_queue.put(f"[{stamp}] {message}")

    def process_log_queue(self):
        try:
            while True:
                message = self.log_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
        except queue.Empty:
            pass

        self.after(100, self.process_log_queue)

    def set_busy(self, busy):
        if busy:
            self.sync_btn.configure(state="disabled")
            self.test_btn.configure(state="disabled")
            self.stop_btn.configure(state="normal")
            self.status_var.set("Sedang sync...")
        else:
            self.sync_btn.configure(state="normal")
            self.test_btn.configure(state="normal")
            self.stop_btn.configure(state="disabled")
            self.status_var.set("Siap.")

    def test_destination(self):
        name = self.dest_var.get().strip()

        if not name:
            messagebox.showwarning(
                "Test", "Pilih laptop tujuan."
            )
            return

        settings = self.config_data["destinations"][name]

        self.status_var.set(
            f"Menguji koneksi {name}..."
        )
        self.log(f"Test connection -> {name}")

        def worker():
            syncer = MySQLSync(
                self.config_data, self.state, self.log
            )

            try:
                version = syncer.test_connection(settings)

                self.log(
                    f"Koneksi OK -> {name} | Server {version}"
                )

                self.after(
                    0,
                    lambda: messagebox.showinfo(
                        "Connection OK",
                        f"Berhasil terhubung ke {name}\n"
                        f"Server: {version}"
                    )
                )

            except Exception as exc:
                self.log(
                    f"Koneksi GAGAL -> {name} | {exc}"
                )

                self.after(
                    0,
                    lambda: messagebox.showerror(
                        "Connection Failed",
                        str(exc)
                    )
                )
            finally:
                self.after(
                    0,
                    lambda: self.status_var.set("Siap.")
                )

        threading.Thread(
            target=worker, daemon=True
        ).start()

    def start_sync(self, silent=False):
        if self.sync_thread and self.sync_thread.is_alive():
            if not silent:
                messagebox.showinfo(
                    "Sync", "Sync masih berjalan."
                )
            return

        destination_name = self.dest_var.get().strip()

        if not destination_name:
            messagebox.showwarning(
                "Sync", "Pilih laptop tujuan."
            )
            return

        save_json(CONFIG_FILE, self.config_data)

        self.set_busy(True)

        if not silent:
            self.log("Memulai sync manual...")

        self.current_syncer = MySQLSync(
            self.config_data,
            self.state,
            self.log
        )

        def worker():
            try:
                self.current_syncer.sync_destination(
                    destination_name
                )

                self.after(
                    0,
                    lambda: self.status_var.set(
                        "Sync selesai: "
                        + datetime.now().strftime("%H:%M:%S")
                    )
                )

            except Exception as exc:
                self.log("ERROR: " + str(exc))
                self.log(traceback.format_exc())

                self.after(
                    0,
                    lambda: self.status_var.set(
                        "Sync gagal. Cek log."
                    )
                )

            finally:
                self.after(
                    0,
                    lambda: self.set_busy(False)
                )

        self.sync_thread = threading.Thread(
            target=worker, daemon=True
        )
        self.sync_thread.start()

    def stop_sync(self):
        if self.current_syncer:
            self.current_syncer.stop()
            self.log(
                "STOP dikirim. Program berhenti setelah batch aktif selesai."
            )

    def toggle_auto_sync(self):
        enabled = self.auto_var.get()

        try:
            seconds = max(
                10, int(self.interval_var.get())
            )
        except ValueError:
            messagebox.showwarning(
                "Auto Sync",
                "Interval harus berupa angka."
            )
            self.auto_var.set(False)
            return

        self.config_data["auto_sync_enabled"] = enabled
        self.config_data["auto_sync_seconds"] = seconds

        save_json(CONFIG_FILE, self.config_data)

        if enabled:
            self.log(
                f"Auto sync AKTIF setiap {seconds} detik."
            )
            self.schedule_auto_sync(initial=False)
        else:
            self.log("Auto sync NONAKTIF.")

            if self.auto_after_id:
                self.after_cancel(self.auto_after_id)
                self.auto_after_id = None

    def schedule_auto_sync(self, initial=False):
        if self.auto_after_id:
            self.after_cancel(self.auto_after_id)

        seconds = max(
            10,
            int(self.config_data.get(
                "auto_sync_seconds", 300
            ))
        )

        delay = 1000 if initial else seconds * 1000
        self.auto_after_id = self.after(
            delay, self.run_auto_sync
        )

    def run_auto_sync(self):
        self.auto_after_id = None

        if self.auto_var.get():
            self.start_sync(silent=True)
            self.schedule_auto_sync(initial=False)

    def on_close(self):
        if self.sync_thread and self.sync_thread.is_alive():
            close_ok = messagebox.askyesno(
                "Tutup",
                "Sync masih berjalan. Tetap tutup program?"
            )

            if not close_ok:
                return

        try:
            self.config_data["auto_sync_enabled"] = (
                self.auto_var.get()
            )
            self.config_data["auto_sync_seconds"] = max(
                10, int(self.interval_var.get())
            )

            save_json(
                CONFIG_FILE,
                self.config_data
            )
            save_json(
                STATE_FILE,
                self.state
            )
        except Exception:
            pass

        self.destroy()


if __name__ == "__main__":
    app = App()
    app.mainloop()
